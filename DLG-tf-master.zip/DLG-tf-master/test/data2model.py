file1 = open("test.txt")
cc = open("context.txt","w")#("../data/ubuntu-10k/test.context.txt","w")
for line in file1:
    split = line.decode('utf-8').split("<s>")
    sen=""
    for ss in split:
        ss=ss.strip()
        if len(ss)==0:
            continue
        sen += " ".join(w for w in ss[:])
    sen+=" </d> "
    cc.write("%s\n"%(sen.encode("utf-8")))

